"use strict";
(() => {
  // src/extension/popup/aggregate.ts
  var CATEGORIES = ["command", "credential", "payment", "support"], TIER = { none: 0, observed_instruction: 1, suspicious_correlation: 2, manipulative_instruction: 3 }, RISK = { high: 1, medium: 0 }, CONF = { high: 2, medium: 1, low: 0 };
  function compareRefs(a, b) {
    return TIER[b.classification] - TIER[a.classification] || RISK[b.actionRisk] - RISK[a.actionRisk] || CONF[b.confidence] - CONF[a.confidence] || CATEGORIES.indexOf(a.category) - CATEGORIES.indexOf(b.category) || a.index - b.index;
  }
  function refsOf(r) {
    let locs = (ev) => [...new Set(ev.flatMap((e) => e.locator ? [e.locator] : []))], make = (category, f, index) => ({ key: `${category}:${f.id}`, category, id: f.id, ruleId: f.ruleId, classification: f.classification, confidence: f.confidence, actionRisk: f.actionRisk, locators: locs(f.evidence), index });
    return [
      ...r.findings.map((f, i) => make("command", f, i)),
      ...r.credential.findings.map((f, i) => make("credential", f, i)),
      ...r.payment.findings.map((f, i) => make("payment", f, i)),
      ...r.support.findings.map((f, i) => make("support", f, i))
    ];
  }
  function groupRefs(refs) {
    let parent = refs.map((_, i) => i), find = (i) => parent[i] === i ? i : parent[i] = find(parent[i]), owner = /* @__PURE__ */ new Map();
    refs.forEach((ref, i) => {
      for (let loc of ref.locators) {
        let j = owner.get(loc);
        j === void 0 ? owner.set(loc, i) : parent[find(i)] = find(j);
      }
    });
    let byRoot = /* @__PURE__ */ new Map();
    return refs.forEach((ref, i) => byRoot.set(find(i), [...byRoot.get(find(i)) ?? [], ref])), [...byRoot.values()].map((members) => {
      members.sort(compareRefs);
      let top = members[0], shared = /* @__PURE__ */ new Map();
      if (members.length > 1)
        for (let loc of new Set(members.flatMap((m) => m.locators))) {
          let cats = [...new Set(members.filter((m) => m.locators.includes(loc)).map((m) => m.category))];
          members.filter((m) => m.locators.includes(loc)).length > 1 && shared.set(loc, cats);
        }
      return { key: members.map((m) => m.key).join("+"), members, classification: top.classification, actionRisk: top.actionRisk, shared };
    }).sort((a, b) => compareRefs(a.members[0], b.members[0]));
  }
  function aggregate(r) {
    let refs = refsOf(r), verdictOf = { command: r.verdict, credential: r.credential.verdict, payment: r.payment.verdict, support: r.support.verdict }, categories = Object.fromEntries(CATEGORIES.map((c) => {
      let mine = refs.filter((x) => x.category === c);
      return [c, { verdict: verdictOf[c], total: mine.length, actionable: mine.filter((x) => x.classification !== "observed_instruction").length }];
    })), highest = CATEGORIES.map((c) => verdictOf[c]).reduce((a, b) => TIER[b] > TIER[a] ? b : a, "none"), groups = groupRefs(refs);
    return {
      highest,
      actionable: refs.filter((x) => x.classification !== "observed_instruction").length,
      affected: CATEGORIES.filter((c) => categories[c].actionable > 0),
      categories,
      groups: groups.filter((g) => g.classification !== "observed_instruction"),
      observed: groups.filter((g) => g.classification === "observed_instruction"),
      complete: r.status.complete
    };
  }

  // src/extension/auto/auto.ts
  function summarize(r) {
    let d = aggregate(r);
    return { type: "veiltrace:auto", v: 1, verdict: d.highest, actionable: d.actionable };
  }

  // src/extension/auto/channel.ts
  function sendAutoSummary(s) {
    chrome.runtime.sendMessage(s).catch(() => {
    });
  }

  // src/extension/auto/content-auto.ts
  var DEBOUNCE_MS = 1200, MAX_WAIT_MS = 5e3, MIN_INTERVAL_MS = 4e3, MAX_SCANS = 25, scans = 0, lastScan = -1 / 0, timer, pendingSince, lastSent = "";
  function run() {
    if (timer = void 0, pendingSince = void 0, document.hidden || scans >= MAX_SCANS) return;
    let wait = lastScan + MIN_INTERVAL_MS - performance.now();
    if (wait > 0) {
      timer = setTimeout(run, wait);
      return;
    }
    scans++, lastScan = performance.now();
    let summary;
    try {
      summary = summarize(VeiltraceContent.scan({ keepHighlight: !0 }));
    } catch {
      return;
    }
    let key = `${summary.verdict}:${summary.actionable}`;
    key !== lastSent && (lastSent = key, sendAutoSummary(summary)), scans >= MAX_SCANS && observer.disconnect();
  }
  function schedule() {
    let now = performance.now();
    pendingSince ??= now, timer !== void 0 && clearTimeout(timer), timer = setTimeout(run, Math.min(DEBOUNCE_MS, Math.max(0, pendingSince + MAX_WAIT_MS - now)));
  }
  var ownNode = (n) => n instanceof Element && n.hasAttribute("data-veiltrace-highlight"), observer = new MutationObserver((records) => {
    records.every((r) => ownNode(r.target) || [...r.addedNodes, ...r.removedNodes].some(ownNode)) || schedule();
  });
  window.top === window && (observer.observe(document.documentElement, { childList: !0, subtree: !0, characterData: !0 }), document.addEventListener("visibilitychange", () => {
    document.hidden || schedule();
  }), run());
})();
