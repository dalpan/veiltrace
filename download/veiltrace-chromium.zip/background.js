"use strict";
(() => {
  // src/extension/auto/auto.ts
  var MANAGED = !1, AUTO_SCRIPT_ID = "veiltrace-auto", AUTO_ORIGINS = ["http://*/*", "https://*/*"], VERDICTS = ["none", "observed_instruction", "suspicious_correlation", "manipulative_instruction"];
  function parseAutoSummary(x) {
    if (typeof x != "object" || x === null || Array.isArray(x)) return null;
    let o = x;
    return Object.keys(o).sort().join() !== "actionable,type,v,verdict" || o.type !== "veiltrace:auto" || o.v !== 1 || !VERDICTS.includes(o.verdict) || typeof o.actionable != "number" || !Number.isInteger(o.actionable) || o.actionable < 0 || o.actionable > 1e3 ? null : { type: "veiltrace:auto", v: 1, verdict: o.verdict, actionable: o.actionable };
  }
  function badgeFor(s) {
    return s.verdict === "manipulative_instruction" ? { text: "!", color: "#c8463f" } : { text: "", color: "#3d4739" };
  }
  var SCRIPT = { id: AUTO_SCRIPT_ID, matches: AUTO_ORIGINS, js: ["content.js", "auto.js"], runAt: "document_idle", allFrames: !1 };
  async function register() {
    (await chrome.scripting.getRegisteredContentScripts({ ids: [AUTO_SCRIPT_ID] })).length > 0 || await chrome.scripting.registerContentScripts([{ ...SCRIPT, persistAcrossSessions: !0 }]).catch(() => chrome.scripting.registerContentScripts([SCRIPT]));
  }
  async function ensureManagedAuto() {
    MANAGED && await chrome.permissions.contains({ origins: AUTO_ORIGINS }) && await register();
  }

  // src/extension/auto/channel.ts
  function onAutoSummary(handler) {
    chrome.runtime.onMessage.addListener((message, sender) => {
      let tabId = sender.tab?.id;
      if (sender.id !== chrome.runtime.id || tabId === void 0 || sender.frameId !== 0) return;
      let s = parseAutoSummary(message);
      s && handler(tabId, s);
    });
  }

  // src/extension/popup/i18n.ts
  var EN = {
    locale: "en-US",
    tagline: "Uncover the manipulation behind the page",
    pageLabel: "Page",
    noPage: "No page",
    protectedPage: "Protected page",
    scan: "Scan page",
    scanAgain: "Scan again",
    scanning: "Scanning this page on your device\u2026",
    scanFinished: "Scan finished.",
    languageLabel: "Language",
    limitsSummary: "What VeilTrace can and cannot see",
    limitsText: 'VeilTrace analyzes visible page text and some hidden clipboard text, on this device only. On request ("Read text in images"), it also reads text inside images on the visible part of the page, also on this device. It does not examine videos, audio, scripts, images outside the visible area or content from other sites inside frames, and it can miss instructions worded in unusual ways or text the reader cannot make out. A result without findings is not a guarantee.',
    metaIdle: "Runs on this device only. Nothing is sent anywhere.",
    meta: (engine, extractor, ms) => `Engine ${engine} \xB7 extractor ${extractor} \xB7 ${ms} ms \xB7 on this device only`,
    partialQualifier: " Part of the page could not be examined (see below).",
    classification: { manipulative_instruction: "Manipulative", suspicious_correlation: "Suspicious", observed_instruction: "Observed" },
    findingTitle: { manipulative_instruction: "Manipulative instruction", suspicious_correlation: "Suspicious instruction", observed_instruction: "Observed instruction" },
    confidence: { high: "Confidence: high", medium: "Confidence: medium", low: "Confidence: low" },
    confidenceHelp: "How strongly the evidence supports this classification.",
    actionRisk: {
      high: "Action risk: high. Following it would run code on your computer.",
      medium: "Action risk: medium. Part of a sequence that runs code."
    },
    ruleChip: (id) => `Rule ${id}`,
    rule: {
      R1: "Asks you to open Run or a terminal, paste and execute, presented as a human-verification (CAPTCHA) step.",
      R2: "Puts a command on your screen or clipboard and presents running it as a human-verification step.",
      R3: "Contains part of an open, paste and execute sequence, presented as a human-verification step.",
      R4: 'Asks you to run code and uses urgency, claimed authority or a "fix this error" story nearby.',
      R5: "Contains an instruction to run code, with no manipulation signs in the same part of the page."
    },
    signal: {
      "A.OPEN_RUN": "Open Run / terminal",
      "A.PASTE": "Paste step",
      "A.EXECUTE": "Execute step",
      "A.COMMAND": "Shell command",
      "A.COPY_TRIGGER": "Copy / verify control",
      "P.HUMAN_VERIFY": "Fake human verification",
      "P.FAKE_FIX": 'Error or "fix" pretext',
      "P.URGENCY": "Urgency or threat",
      "P.AUTHORITY": "Claimed authority",
      "C.NEGATION": "Negation",
      "C.REPORTED": "Reported speech",
      "C.EDUCATIONAL": "Educational context"
    },
    source: { "visible-text": "Visible text", "hidden-clipboard": "Hidden clipboard text", "copy-control": "Copy button" },
    deobfuscated: "disguised characters normalized",
    showOnPage: "Show on page",
    evidenceAria: "Evidence",
    highlight: {
      highlighted: "Highlighted on the page.",
      "invalid-locator": "This evidence cannot be located on the page.",
      "not-found": "This element is no longer on the page. The page may have changed since the scan; scan again.",
      "frame-inaccessible": "This evidence is inside an embedded frame that VeilTrace cannot highlight.",
      "not-visible": "This evidence is not visible on the page (for example, hidden clipboard text).",
      failed: "Could not highlight: the page is no longer accessible. Scan again."
    },
    completeTitle: "Complete scan",
    completeText: (n) => `${n} text blocks analyzed. Complete within what VeilTrace can see.`,
    partialTitle: "Partial scan: some content was not examined",
    partialFooter: (n) => `Findings cover only the ${n} text blocks that were analyzed.`,
    partial: {
      "node-budget": "The page is very large. Analysis stopped at the element limit.",
      "block-budget": "The page is very large. Only the first 5,000 text blocks were analyzed.",
      "char-budget": "The page contains a lot of text. Analysis stopped at the text limit.",
      timeout: "Analysis reached its time limit. The rest of the page was not examined.",
      "block-text-capped": "Some very long text blocks were only partly analyzed.",
      "aux-capped": "The page has many copy buttons or hidden clipboard texts. Some were skipped.",
      "frames-skipped": "Embedded frames from other sites could not be examined.",
      "closed-shadow-skipped": "Some embedded page components could not be examined.",
      "extractor-truncated": "Some content was skipped.",
      "core-truncated": "Some content exceeded the analysis limits and was skipped."
    },
    loweredFrom: (cls) => `Lowered from ${cls.toLowerCase()} because of context: `,
    contextPrefix: "Context: ",
    modifier: {
      "C.QUOTED": "the instruction is inside a quotation.",
      "C.REPORTED": "the text reports what someone else was told to do.",
      "C.EDUCATIONAL": "the surrounding text is educational or awareness material.",
      "C.CODE_EXAMPLE": "the instruction is a code example inside an article.",
      "C.PROCEDURAL": "the instruction is a step in a procedural document."
    },
    override: {
      "O.CONCEALED_PAYLOAD": "Not lowered: this part of the page also places hidden text on your clipboard, which a quotation or tutorial would not do.",
      "O.VERIFICATION_GATE": "Not lowered: the instruction sits in a short verification dialog addressed to you."
    },
    overrideCapped: "Lowered by at most one level: the instruction sits in a short verification dialog addressed to you.",
    contextSetAside: "Context set aside",
    overrideEvidence: "Supporting evidence",
    moreEvidence: (n) => `${n} more evidence item(s) not shown.`,
    moreFindings: (n) => `${n} more finding(s) not shown (display limit).`,
    severity: { manipulative_instruction: "Severity: high", suspicious_correlation: "Severity: medium", observed_instruction: "Severity: informational" },
    cred: {
      experimental: "Experimental",
      findingTitle: { manipulative_instruction: "Manipulative request for a secret", suspicious_correlation: "Suspicious request for a secret", observed_instruction: "Sign-in or code request" },
      ruleChip: (id) => `Rule ${id}`,
      rule: {
        CR1: "Asks you to send a secret to a person or channel. Real services ask you to type codes into their own form, never to pass them on.",
        CR2: "Asks for a wallet recovery phrase and wraps the request in a pretext. Anyone with the phrase controls the wallet.",
        CR3: "Asks for a secret inside content the site may not control (comments, widgets, embedded frames), together with a pretext.",
        CR4: "Asks for a secret together with a threat to suspend, lock or close your account.",
        CR5: "Asks for a password or code with no manipulation signs nearby."
      },
      asks: (action, secrets) => action === "send" ? `Asks you to send: ${secrets}` : `Asks you to enter: ${secrets}`,
      secret: { password: "password", otp: "one-time code", pin: "PIN", "recovery-code": "recovery code", "recovery-phrase": "recovery phrase", token: "access token" },
      indicators: "Indicators",
      pretext: {
        "CP.ACCOUNT_THREAT": "threat to the account",
        "CP.URGENCY": "deadline or urgency",
        "CP.SUPPORT": "claims to be support or an official",
        "CP.VERIFY": "verification framing",
        "CP.REWARD": "prize or reward"
      },
      trust: {
        "user-content": "in user-posted content",
        "third-party-widget": "in an embedded widget",
        "embedded-frame": "in an embedded frame",
        dialog: "in a dialog",
        overlay: "in an overlay",
        form: "in a form"
      },
      destination: {
        none: "The form submits to this page.",
        "same-origin": "The form submits to this site.",
        "other-origin": "The form submits to another site.",
        mailto: "The form opens an email message.",
        javascript: "The form is handled by a script on the page.",
        data: "The form submits to an inline data address.",
        other: "The form submits to an unusual address."
      },
      actionRisk: {
        high: "Action risk: high. Whoever gets this can take over the account or wallet.",
        medium: "Action risk: medium. Entering it on the wrong site can expose your account."
      },
      modifier: {
        "C.QUOTED": "the request is inside a quotation.",
        "C.REPORTED": "the text reports what someone else was asked to do.",
        "C.EDUCATIONAL": "the surrounding text is educational or awareness material.",
        "C.CODE_EXAMPLE": "the request is inside a code sample."
      },
      overrideLiveField: "Not lowered: the same part of the page has a working input field for the secret.",
      signal: {
        "S.PASSWORD": "Password",
        "S.OTP": "One-time code",
        "S.PIN": "PIN",
        "S.RECOVERY_CODE": "Recovery code",
        "S.SEED_PHRASE": "Recovery phrase",
        "S.TOKEN": "Access token",
        "D.SEND": "Send or share",
        "D.ENTER": "Enter",
        "CP.ACCOUNT_THREAT": "Account threat",
        "CP.URGENCY": "Urgency",
        "CP.SUPPORT": "Claimed support or authority",
        "CP.VERIFY": "Verification framing",
        "CP.REWARD": "Reward",
        "F.SECRET_FIELD": "Input field",
        "C.NEGATION": "Negation",
        "C.REPORTED": "Reported speech",
        "C.EDUCATIONAL": "Educational context"
      },
      fieldSource: "Form field",
      fieldKind: {
        password: "password",
        otp: "one-time code",
        pin: "PIN",
        "recovery-code": "recovery code",
        "secret-phrase": "recovery phrase",
        email: "email",
        text: "text",
        other: "other"
      },
      unlabeledField: "(field without a label)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace cannot verify who wrote this. A claim to be support or an official is not proof.",
        "destination-not-scored": "Where the form submits is shown for information only; VeilTrace does not judge sites.",
        "trust-boundary-heuristic": "Whether this content comes from the site or from others is estimated from the page structure."
      }
    },
    pay: {
      findingTitle: { manipulative_instruction: "Manipulative payment request", suspicious_correlation: "Suspicious payment request", observed_instruction: "Payment request" },
      ruleChip: (id) => `Rule ${id}`,
      rule: {
        PR1: "Asks you to pay first in order to receive something (a refund, a prize, released funds or an unlocked account). Real refunds and prizes never require an upfront payment.",
        PR2: "Asks you to pay outside an ordinary checkout (a personal account, off the platform, gift cards or cryptocurrency), together with pressure. Such payments are hard to get back.",
        PR3: "Asks for a payment together with a threat (account closure, arrest or legal action) and urgency or a claimed authority.",
        PR4: "Asks for a payment with no manipulation signs nearby."
      },
      promise: { refund: "a refund", prize: "a prize", "account-unlock": "an unlocked account", release: "released money or goods", recruitment: "a guaranteed place in a selection", job: "a job", "investment-return": "a fixed or guaranteed investment return", loan: 'a loan that is "approved" or "sure to be paid out"' },
      destination: { "personal-account": "a personal account", "off-platform": "outside the platform", "gift-card": "gift cards", crypto: "cryptocurrency" },
      pressure: { threat: "threat", urgency: "deadline or urgency", "claimed-authority": "claims to be support or an authority", "claimed-family": "claims to be a family member on a new number" },
      promisesLabel: "Promised in return",
      destinationsLabel: "Payment goes to",
      indicators: "Indicators",
      actionRisk: {
        high: "Action risk: high. Money sent this way is usually lost.",
        medium: "Action risk: medium. Paying the wrong party can cost you money."
      },
      signal: {
        "PY.PAY": "Payment request",
        "PA.AMOUNT": "Amount",
        "PF.FEE": "Fee",
        "PF.RELEASE_FEE": "Fee to release or unlock",
        "PD.PERSONAL": "Personal account",
        "PD.OFF_PLATFORM": "Outside the platform",
        "PD.GIFT_CARD": "Gift cards",
        "PD.CRYPTO": "Cryptocurrency",
        "PR.REFUND": "Refund or held money",
        "PR.PRIZE": "Prize",
        "PR.UNLOCK": "Account unlock",
        "PR.RECRUIT": "Guaranteed selection",
        "PR.JOB": "Job offer",
        "PC.CONDITION": "Payment as a condition",
        "PP.THREAT": "Threat",
        "PP.FAMILY": "Claimed family member",
        "PP.URGENCY": "Urgency",
        "PP.AUTHORITY": "Claimed support or authority",
        "C.NEGATION": "Negation",
        "C.REPORTED": "Reported speech",
        "C.EDUCATIONAL": "Educational context"
      },
      amountHidden: "(amount on the page; the value is not shown)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace cannot verify who wrote this. A claim to be support, a bank or the police is not proof.",
        "trust-boundary-heuristic": "Whether this content comes from the site or from others is estimated from the page structure.",
        "amount-not-reported": "Amounts are matched to understand the request, but their values are never copied into the report."
      }
    },
    sup: {
      findingTitle: { manipulative_instruction: "Manipulative support direction", suspicious_correlation: "Suspicious support direction", observed_instruction: "Support direction" },
      ruleChip: (id) => `Rule ${id}`,
      rule: {
        SR1: "The web page claims your device is infected or locked and tells you to call, install or allow access. Browsers and operating systems do not show such alarms inside web pages.",
        SR2: "Someone presenting as support, a bank or an administrator asks you to install software or allow remote access, under pressure or from content the site may not control.",
        SR3: "Someone presenting as support, a bank or an administrator sends you to an outside contact together with a threat to your account or data.",
        SR4: "A comment or other user-posted content presents itself as official support and sends you to an outside contact.",
        SR5: "Directs you to contact support, install software or allow remote access, with no impersonation or pressure signs nearby.",
        SR6: "A message presented as a notice from a bank, e-wallet, marketplace or its support raises an alarm, a threat or a reward and asks you to reply, choose an option, open a link or fill in a form. Banks and platforms do not settle such matters through a reply or a link in a message.",
        SR7: "Congratulates you on a cash prize you did not enter for and asks you to answer a quiz, often in a company's name. Such quizzes lead people to share the link or hand over data or money.",
        SR8: "Offers to get into someone else's messages, account or phone and sends you to a contact. Such services are illegal, and buyers are commonly cheated or blackmailed.",
        SR9: "Someone presenting as a buyer, tenant or landlord sends you to a relative or another person on a personal number to settle a price or payment. Fake-buyer and payment-redirect scams start this way.",
        SR10: "A message offers an Android app file (.apk) presented as an invitation, a parcel photo, a receipt, a ticket or a bill, or asks you to install it or to turn off your phone's protection. Opening such a file installs an app that can read your text messages and take over banking apps."
      },
      action: { contact: "contact someone", respond: "reply, choose an option, open a link or fill in a form", survey: "answer a quiz or questionnaire", "remote-access": "allow remote access", install: "install software", "disable-protection": "turn off your device's protection or allow unknown apps" },
      channel: { phone: "phone number", mobile: "mobile number", messenger: "messaging app", link: "link", "apk-file": "app file (.apk)" },
      claim: { support: "support or customer service", bank: "a bank", administrator: "an administrator", "security-team": "a security team", official: "an official, officer or investigator", organization: "a company or institution" },
      indicator: {
        "page-rendered-system-alert": "virus or lock alarm shown by the web page",
        "remote-access-request": "asks for remote access",
        "software-install-request": "asks you to install software",
        "personal-channel-contact": "official-sounding claim with a mobile number or messaging app",
        "claim-in-user-content": "official claim inside user-posted content",
        "alert-in-overlay": "alarm in an overlay covering the page",
        "protection-disable-request": "asks you to turn off protection, allow unknown apps or grant accessibility",
        "apk-file-in-message": "app file (.apk) sent in a message"
      },
      pressure: { "system-alert": "device alarm", "account-alarm": "account alarm (sign-in, transaction or tariff)", threat: "threat to the account or data", urgency: "deadline or urgency", reward: "reward or points", "pre-won": "congratulations on a prize you did not enter for", "illicit-access": "offer to get into someone else's account or phone", "third-party-redirect": "sends you to a relative or proxy on a personal number", "document-pretext": "presented as an invitation, parcel photo, receipt, ticket or bill" },
      asksLabel: "Asks you to",
      claimsLabel: "Claims to be (not verified)",
      indicatorsLabel: "Observed indicators",
      pressureLabel: "Pressure",
      actionRisk: {
        high: "Action risk: high. Installing software or allowing remote access can give a stranger control of your device.",
        medium: "Action risk: medium. Contacting a fake support line can lead to requests for money, codes or access."
      },
      signal: {
        "SC.CONTACT": "Contact direction",
        "SC.RESPOND": "Reply, link or form request",
        "SC.SURVEY": "Quiz or questionnaire",
        "SA.REMOTE": "Remote access request",
        "SA.INSTALL": "Install request",
        "SX.PHONE": "Phone number",
        "SX.MOBILE": "Mobile number",
        "SX.MESSENGER": "Messaging app",
        "SX.LINK": "Link",
        "SI.SUPPORT": "Claimed support",
        "SI.BANK": "Claimed bank",
        "SI.ADMIN": "Claimed administrator",
        "SI.SECURITY": "Claimed security team",
        "SI.OFFICIAL": "Claimed official or rank",
        "SW.ALERT": "Device alarm",
        "ST.THREAT": "Threat",
        "SU.URGENCY": "Urgency",
        "SW.ACCOUNT": "Account alarm",
        "SP.REWARD": "Reward",
        "SP.WON": "Unentered prize",
        "SO.ILLICIT": "Illegal access offer",
        "SO.PROXY": "Redirect to a relative or proxy",
        "SI.ORG": "Claimed company or institution",
        "SH.UNASSERTED": "Condition or attribution",
        "C.NEGATION": "Negation",
        "C.REPORTED": "Reported speech",
        "C.EDUCATIONAL": "Educational context"
      },
      contactHidden: "(contact number on the page; not shown)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace cannot verify who wrote this. A claim to be support, a bank or an administrator is not proof, and VeilTrace does not say the organization itself is fake.",
        "trust-boundary-heuristic": "Whether this content comes from the site or from others is estimated from the page structure.",
        "contact-details-not-reported": "Phone numbers are matched to understand the direction, but are never copied into the report."
      }
    },
    pwa: {
      title: "Check a message",
      intro: "Paste a suspicious message, or check a screenshot of it, to see whether it tries to manipulate you. Screenshots are read on this device.",
      sourceLabel: "Where is it from?",
      source: { chat: "Chat (WhatsApp, Telegram\u2026)", sms: "SMS", email: "Email", web: "Text from a website" },
      placeholder: "Paste the message here\u2026",
      check: "Check message",
      clear: "Clear",
      paste: "Paste from clipboard",
      shareHint: "On Android, install this app, then share a message or a screenshot to VeilTrace.",
      privacy: "Checked on this device only. The message is not sent, saved or shared.",
      empty: "Paste or share a message first.",
      tooLong: "Only the first 20,000 characters were checked.",
      assessment: "MESSAGE THREAT ASSESSMENT",
      headlineDetail: {
        manipulative_instruction: "This message tries to make you do something harmful. Do not follow the instructions listed below.",
        suspicious_correlation: "This message combines requests with signs often seen in scams. Check the findings below before you act.",
        observed_instruction: "Ordinary instructions or requests were found and are listed as observed. This is not a guarantee about the message.",
        none: "VeilTrace found nothing to report in this text. This is not a guarantee about the message or its sender."
      },
      linkOnly: "Only a link was pasted. VeilTrace checks what a message says and does not judge web addresses. Paste the whole message, including the text around the link. Do not open the link just to check it.",
      yourMessage: "Your message",
      offlineReady: "Ready to work offline.",
      image: "Check a screenshot",
      ocrProgress: (p) => `Reading the text in the image on this device\u2026 ${p}%`,
      ocrDone: "Text read from the image. Compare it with the image and correct it if needed, then check again.",
      ocrEmpty: "No text could be read from this image. Try a sharper screenshot, or paste the text.",
      ocrFailed: "The image could not be read on this device. Paste the text instead."
    },
    imageText: {
      title: "Text in images \xB7 on this device",
      intro: "Some lures are drawn inside images (posters, banners, photographed letters). VeilTrace can read the visible part of this page from a screenshot, on this device, and check the text that is not already page text. Nothing is sent.",
      run: "Read text in images",
      reading: (p) => `Reading the visible screen on this device\u2026 ${p}%`,
      analyzing: "Checking the text found in images\u2026",
      done: (n) => `${n} line${n === 1 ? "" : "s"} of text found only in images on the visible screen.`,
      nothing: "No text was found in images on the visible screen beyond what the page already shows as text. Scroll and read again to check other parts.",
      noText: "No text could be read from the visible screen.",
      failed: "The screen could not be read here. Some pages and browsers do not allow a screenshot.",
      notShowable: "Inside an image: it cannot be highlighted on the page."
    },
    ai: {
      title: "AI second opinion \xB7 optional, on this device",
      intro: "The AI model built into Chrome can read this page's text and give a second opinion. It runs on this device and nothing is sent. The VeilTrace result above does not change.",
      prepare: "Show the text the AI will read",
      previewSummary: (n, cut) => `${n} lines of page text; numbers, links and email addresses are masked${cut ? "; cut to fit" : ""}`,
      run: "Ask the on-device AI",
      running: "The AI is reading the text\u2026",
      downloading: (p) => `Chrome is downloading its AI model\u2026 ${p}%`,
      unsupported: "Not available in this browser. The on-device AI needs Chrome on Windows, macOS, Linux or a Chromebook Plus with its built-in model.",
      unavailable: "Chrome's built-in AI model is not available on this device (hardware, free storage or settings).",
      failed: "The AI did not give a usable answer. Try again.",
      noText: "There is no page text to read.",
      resultTitle: "AI opinion \xB7 may be wrong",
      assessment: { manipulative: "The AI sees signs of manipulation.", suspicious: "The AI sees some suspicious signs.", "no-clear-signs": "The AI sees no clear signs of manipulation. This is not a guarantee." },
      tactic: {
        impersonation: "claims to be a bank, company, support or official",
        "threat-or-urgency": "threat, alarm or deadline",
        "too-good-to-be-true": "prize, refund or job that is too good to be true",
        "payment-request": "asks for a payment",
        "credential-request": "asks for a password, code or PIN",
        "link-or-reply-lure": "link, reply, quiz or form as a lure",
        "run-command": "asks you to run a command",
        "remote-access-or-install": "asks you to install an app or allow remote access",
        "illegal-service": "offers an illegal service",
        "personal-contact-channel": "personal phone number or messenger"
      },
      confidence: { low: "AI confidence: low", medium: "AI confidence: medium", high: "AI confidence: high" },
      tacticsLabel: "Tactics the AI names",
      citedLines: "Lines the AI points to",
      disagreeAlert: "The AI and VeilTrace disagree. VeilTrace found no documented manipulation pattern on this page. Read the lines the AI points to yourself: the AI may be wrong.",
      disagreeQuiet: "The AI and VeilTrace disagree. The AI does not see what VeilTrace found; VeilTrace's findings above show the evidence they are based on.",
      caveat: "An opinion from a language model: it can be wrong or misled by the page itself, and Indonesian is not one of its supported languages. It does not change the VeilTrace result."
    },
    auto: {
      actionTitle: "VeilTrace: scan this page",
      badgeTitle: "VeilTrace: manipulative content found on this page. Click for details.",
      title: "Scan mode",
      modeLabel: { manual: "MANUAL", automatic: "AUTO" },
      manualText: "Manual: VeilTrace reads a page only when you click Scan page.",
      automaticText: 'Automatic: VeilTrace checks pages as they load and change, and marks the toolbar icon with "!" when it finds manipulative content.',
      consent: "Your browser will ask you to let VeilTrace read all websites. Pages are still analyzed only on this device: nothing is sent, stored or shared, and form values are never read. It applies to pages opened or reloaded afterwards, and you can turn it off here or in Chrome settings at any time.",
      managedText: "Automatic scanning is turned on by your organization. Pages are still analyzed only on this device; nothing is reported to your organization or anyone else.",
      enable: "Turn on automatic scanning",
      disable: "Turn off automatic scanning",
      denied: "Permission not granted. VeilTrace stays in manual mode.",
      failed: "The scan mode could not be changed. Try again."
    },
    dash: {
      stateLabel: { standby: "STANDBY", scanning: "SCANNING", complete: "SCAN COMPLETE", partial: "PARTIAL SCAN", error: "SCAN FAILED" },
      assessment: "PAGE THREAT ASSESSMENT",
      headline: {
        manipulative_instruction: {
          tone: "danger",
          title: "Manipulative content detected",
          detail: "This page tries to make you do something harmful. Do not follow the instructions listed below."
        },
        suspicious_correlation: {
          tone: "warning",
          title: "Suspicious content detected",
          detail: "This page combines requests with signs often seen in scams. Check the findings below before you act."
        },
        observed_instruction: {
          tone: "neutral",
          title: "No manipulation signs in the analyzed content",
          detail: "Ordinary instructions or requests were found and are listed as observed. This is not a guarantee about the page."
        },
        none: {
          tone: "neutral",
          title: "Nothing to report in the analyzed content",
          detail: "VeilTrace found no findings in what it could examine. This is not a guarantee about the page."
        }
      },
      statHighest: "Highest classification",
      statActionable: "Actionable findings",
      statCategories: "Affected categories",
      statCoverage: "Scan coverage",
      coverageValue: { complete: "Complete", partial: "Partial" },
      noCategories: "None",
      verdictLabel: { manipulative_instruction: "Manipulative", suspicious_correlation: "Suspicious", observed_instruction: "Observed only", none: "No findings" },
      overviewTitle: "Detection categories",
      categoryName: {
        command: "Command Execution Manipulation",
        credential: "Credential Disclosure Manipulation",
        payment: "Payment Manipulation",
        support: "Support & Authority Impersonation"
      },
      categoryCode: { command: "CMD", credential: "CRED", payment: "PAY", support: "SUP" },
      tileCount: (total, actionable) => total === 0 ? "0 findings" : `${actionable} actionable \xB7 ${total} total`,
      experimental: "Experimental",
      experimentalNote: "Credential, payment and support checks are experimental and have not yet passed an independent evaluation. They read only the page text and form structure, never what you typed, and never copy amounts or phone numbers.",
      findingsTitle: (n) => `Findings (${n})`,
      observedTitle: (n) => `Observed without manipulation signs (${n})`,
      groupTitle: (n) => `${n} related findings on the same page element`,
      groupNote: "Each detector\u2019s finding is shown with its own evidence.",
      alsoCitedBy: (c) => `Also cited by: ${c}`,
      evidenceTitle: "Observed evidence",
      evidenceId: (id) => `Evidence ID ${id}`,
      findingId: (id) => `Finding ID ${id}`,
      actionRiskChip: { high: "Action risk: high", medium: "Action risk: medium" },
      adviceTitle: "What to do",
      advice: {
        command: "Do not press Win+R, open a terminal, paste or run anything this page asks for. A real CAPTCHA never asks you to run commands.",
        credential: "Do not send passwords, one-time codes or recovery phrases to anyone. Sign in only on a site you opened yourself.",
        payment: "Do not pay to receive a refund, prize or unlocked account, and do not pay personal accounts, gift cards or crypto on request. Contact the organization through a channel you already know.",
        support: "Do not call numbers or message accounts shown in alerts or comments. Look up the organization\u2019s contact details yourself.",
        remoteAccess: "Never install remote-access apps (AnyDesk, TeamViewer) or other software because someone claiming to be support asks you to."
      },
      adviceNone: "No findings does not make a page trustworthy. VeilTrace checks only what it can see on this page, at the moment of the scan."
    },
    errors: {
      noPageTitle: "No page to scan",
      noPageDetail: "Open a web page, then click the VeilTrace button again.",
      restrictedTitle: "This page cannot be scanned",
      restrictedDetail: "Browser-protected pages (such as the browser's internal pages, extension stores and other extensions) do not allow extensions to read them.",
      accessTitle: "VeilTrace could not access this page",
      accessDetail: "The page may block extensions or may have changed. Reload the page and try again.",
      fileDetail: `To scan local files, turn on "Allow access to file URLs" for VeilTrace on your browser's extensions page.`,
      badReportTitle: "Scan failed",
      badReportDetail: "The scan returned unexpected data and was discarded."
    }
  }, ID = {
    locale: "id-ID",
    tagline: "Ungkap manipulasi di balik halaman",
    pageLabel: "Halaman",
    noPage: "Tidak ada halaman",
    protectedPage: "Halaman terlindungi",
    scan: "Pindai halaman",
    scanAgain: "Pindai ulang",
    scanning: "Memindai halaman ini di perangkat Anda\u2026",
    scanFinished: "Pemindaian selesai.",
    languageLabel: "Bahasa",
    limitsSummary: "Apa yang bisa dan tidak bisa dilihat VeilTrace",
    limitsText: 'VeilTrace menganalisis teks yang terlihat di halaman dan sebagian teks clipboard tersembunyi, hanya di perangkat ini. Atas permintaan ("Baca teks di gambar"), VeilTrace juga membaca teks di dalam gambar pada bagian halaman yang terlihat, juga di perangkat ini. VeilTrace tidak memeriksa video, audio, skrip, gambar di luar layar yang terlihat, atau konten dari situs lain di dalam frame, dan bisa melewatkan instruksi yang ditulis dengan cara tidak biasa atau teks yang tidak terbaca. Hasil tanpa temuan bukan jaminan.',
    metaIdle: "Berjalan hanya di perangkat ini. Tidak ada data yang dikirim.",
    meta: (engine, extractor, ms) => `Engine ${engine} \xB7 extractor ${extractor} \xB7 ${ms} md \xB7 hanya di perangkat ini`,
    partialQualifier: " Sebagian halaman tidak dapat diperiksa (lihat di bawah).",
    classification: { manipulative_instruction: "Manipulatif", suspicious_correlation: "Mencurigakan", observed_instruction: "Teramati" },
    findingTitle: { manipulative_instruction: "Instruksi manipulatif", suspicious_correlation: "Instruksi mencurigakan", observed_instruction: "Instruksi teramati" },
    confidence: { high: "Keyakinan: tinggi", medium: "Keyakinan: sedang", low: "Keyakinan: rendah" },
    confidenceHelp: "Seberapa kuat bukti mendukung klasifikasi ini.",
    actionRisk: {
      high: "Risiko tindakan: tinggi. Mengikutinya akan menjalankan kode di komputer Anda.",
      medium: "Risiko tindakan: sedang. Bagian dari rangkaian langkah yang menjalankan kode."
    },
    ruleChip: (id) => `Aturan ${id}`,
    rule: {
      R1: "Meminta Anda membuka Run atau terminal, menempelkan, lalu menjalankan, dengan dalih verifikasi manusia (CAPTCHA).",
      R2: "Menaruh perintah di layar atau clipboard Anda dan menyajikan cara menjalankannya sebagai verifikasi manusia.",
      R3: "Memuat sebagian rangkaian buka, tempel, dan jalankan, dengan dalih verifikasi manusia.",
      R4: 'Meminta Anda menjalankan kode dan memakai desakan, klaim otoritas, atau cerita "perbaiki error ini" di dekatnya.',
      R5: "Memuat instruksi untuk menjalankan kode, tanpa tanda manipulasi di bagian halaman yang sama."
    },
    signal: {
      "A.OPEN_RUN": "Buka Run / terminal",
      "A.PASTE": "Langkah tempel",
      "A.EXECUTE": "Langkah jalankan",
      "A.COMMAND": "Perintah shell",
      "A.COPY_TRIGGER": "Tombol salin / verifikasi",
      "P.HUMAN_VERIFY": "Verifikasi manusia palsu",
      "P.FAKE_FIX": 'Dalih error atau "perbaikan"',
      "P.URGENCY": "Desakan atau ancaman",
      "P.AUTHORITY": "Klaim otoritas",
      "C.NEGATION": "Negasi",
      "C.REPORTED": "Kalimat laporan",
      "C.EDUCATIONAL": "Konteks edukasi"
    },
    source: { "visible-text": "Teks terlihat", "hidden-clipboard": "Teks clipboard tersembunyi", "copy-control": "Tombol salin" },
    deobfuscated: "karakter samaran dinormalkan",
    showOnPage: "Tunjukkan di halaman",
    evidenceAria: "Bukti",
    highlight: {
      highlighted: "Ditandai di halaman.",
      "invalid-locator": "Bukti ini tidak dapat ditemukan di halaman.",
      "not-found": "Elemen ini sudah tidak ada di halaman. Halaman mungkin berubah sejak pemindaian; pindai ulang.",
      "frame-inaccessible": "Bukti ini berada di dalam frame tersemat yang tidak dapat ditandai VeilTrace.",
      "not-visible": "Bukti ini tidak terlihat di halaman (misalnya teks clipboard tersembunyi).",
      failed: "Tidak dapat menandai: halaman sudah tidak dapat diakses. Pindai ulang."
    },
    completeTitle: "Pemindaian lengkap",
    completeText: (n) => `${n} blok teks dianalisis. Lengkap sebatas yang dapat dilihat VeilTrace.`,
    partialTitle: "Pemindaian sebagian: ada konten yang tidak diperiksa",
    partialFooter: (n) => `Temuan hanya mencakup ${n} blok teks yang dianalisis.`,
    partial: {
      "node-budget": "Halaman sangat besar. Analisis berhenti di batas jumlah elemen.",
      "block-budget": "Halaman sangat besar. Hanya 5.000 blok teks pertama yang dianalisis.",
      "char-budget": "Halaman berisi sangat banyak teks. Analisis berhenti di batas teks.",
      timeout: "Analisis mencapai batas waktu. Sisa halaman tidak diperiksa.",
      "block-text-capped": "Beberapa blok teks yang sangat panjang hanya dianalisis sebagian.",
      "aux-capped": "Halaman memiliki banyak tombol salin atau teks clipboard tersembunyi. Sebagian dilewati.",
      "frames-skipped": "Frame tersemat dari situs lain tidak dapat diperiksa.",
      "closed-shadow-skipped": "Beberapa komponen halaman tersemat tidak dapat diperiksa.",
      "extractor-truncated": "Sebagian konten dilewati.",
      "core-truncated": "Sebagian konten melebihi batas analisis dan dilewati."
    },
    loweredFrom: (cls) => `Diturunkan dari ${cls.toLowerCase()} karena konteks: `,
    contextPrefix: "Konteks: ",
    modifier: {
      "C.QUOTED": "instruksi berada di dalam kutipan.",
      "C.REPORTED": "teks melaporkan apa yang diminta kepada orang lain.",
      "C.EDUCATIONAL": "teks di sekitarnya adalah materi edukasi atau kewaspadaan.",
      "C.CODE_EXAMPLE": "instruksi adalah contoh kode di dalam artikel.",
      "C.PROCEDURAL": "instruksi adalah langkah dalam dokumen prosedural."
    },
    override: {
      "O.CONCEALED_PAYLOAD": "Tidak diturunkan: bagian halaman ini juga menaruh teks tersembunyi di clipboard Anda, sesuatu yang tidak dilakukan kutipan atau tutorial.",
      "O.VERIFICATION_GATE": "Tidak diturunkan: instruksi berada di dialog verifikasi singkat yang ditujukan kepada Anda."
    },
    overrideCapped: "Diturunkan paling banyak satu tingkat: instruksi berada di dialog verifikasi singkat yang ditujukan kepada Anda.",
    contextSetAside: "Konteks yang dikesampingkan",
    overrideEvidence: "Bukti pendukung",
    moreEvidence: (n) => `${n} bukti lainnya tidak ditampilkan.`,
    moreFindings: (n) => `${n} temuan lainnya tidak ditampilkan (batas tampilan).`,
    severity: { manipulative_instruction: "Tingkat keparahan: tinggi", suspicious_correlation: "Tingkat keparahan: sedang", observed_instruction: "Tingkat keparahan: informasi" },
    cred: {
      experimental: "Eksperimental",
      findingTitle: { manipulative_instruction: "Permintaan rahasia yang manipulatif", suspicious_correlation: "Permintaan rahasia yang mencurigakan", observed_instruction: "Permintaan masuk atau kode" },
      ruleChip: (id) => `Aturan ${id}`,
      rule: {
        CR1: "Meminta Anda mengirim rahasia kepada orang atau kanal. Layanan asli meminta Anda mengetik kode di formulirnya sendiri, tidak pernah meneruskannya.",
        CR2: "Meminta frasa pemulihan dompet dengan suatu dalih. Siapa pun yang memegang frasa itu menguasai dompetnya.",
        CR3: "Meminta rahasia di dalam konten yang mungkin tidak dikendalikan situs (komentar, widget, frame tersemat), disertai dalih.",
        CR4: "Meminta rahasia disertai ancaman untuk menangguhkan, mengunci, atau menutup akun Anda.",
        CR5: "Meminta kata sandi atau kode tanpa tanda manipulasi di sekitarnya."
      },
      asks: (action, secrets) => action === "send" ? `Meminta Anda mengirim: ${secrets}` : `Meminta Anda mengisi: ${secrets}`,
      secret: { password: "kata sandi", otp: "kode sekali pakai (OTP)", pin: "nomor PIN", "recovery-code": "kode pemulihan", "recovery-phrase": "frasa pemulihan", token: "token akses" },
      indicators: "Indikator",
      pretext: {
        "CP.ACCOUNT_THREAT": "ancaman terhadap akun",
        "CP.URGENCY": "tenggat atau desakan",
        "CP.SUPPORT": "mengaku sebagai petugas atau pihak resmi",
        "CP.VERIFY": "dalih verifikasi",
        "CP.REWARD": "hadiah atau imbalan"
      },
      trust: {
        "user-content": "di konten kiriman pengguna",
        "third-party-widget": "di widget tersemat",
        "embedded-frame": "di frame tersemat",
        dialog: "di dalam dialog",
        overlay: "di dalam overlay",
        form: "di dalam formulir"
      },
      destination: {
        none: "Formulir dikirim ke halaman ini.",
        "same-origin": "Formulir dikirim ke situs ini.",
        "other-origin": "Formulir dikirim ke situs lain.",
        mailto: "Formulir membuka pesan email.",
        javascript: "Formulir ditangani skrip di halaman.",
        data: "Formulir dikirim ke alamat data sebaris.",
        other: "Formulir dikirim ke alamat yang tidak biasa."
      },
      actionRisk: {
        high: "Risiko tindakan: tinggi. Siapa pun yang mendapatkannya bisa mengambil alih akun atau dompet.",
        medium: "Risiko tindakan: sedang. Mengisinya di situs yang salah dapat membuka akses ke akun Anda."
      },
      modifier: {
        "C.QUOTED": "permintaan berada di dalam kutipan.",
        "C.REPORTED": "teks melaporkan apa yang diminta dari orang lain.",
        "C.EDUCATIONAL": "teks di sekitarnya adalah materi edukasi atau kesadaran keamanan.",
        "C.CODE_EXAMPLE": "permintaan berada di dalam contoh kode."
      },
      overrideLiveField: "Tidak diturunkan: bagian halaman yang sama memiliki kolom isian yang berfungsi untuk rahasia tersebut.",
      signal: {
        "S.PASSWORD": "Kata sandi",
        "S.OTP": "Kode sekali pakai",
        "S.PIN": "Nomor PIN",
        "S.RECOVERY_CODE": "Kode pemulihan",
        "S.SEED_PHRASE": "Frasa pemulihan",
        "S.TOKEN": "Token akses",
        "D.SEND": "Kirim atau bagikan",
        "D.ENTER": "Isi",
        "CP.ACCOUNT_THREAT": "Ancaman akun",
        "CP.URGENCY": "Desakan",
        "CP.SUPPORT": "Mengaku petugas atau otoritas",
        "CP.VERIFY": "Dalih verifikasi",
        "CP.REWARD": "Hadiah",
        "F.SECRET_FIELD": "Kolom isian",
        "C.NEGATION": "Negasi",
        "C.REPORTED": "Kalimat dilaporkan",
        "C.EDUCATIONAL": "Konteks edukasi"
      },
      fieldSource: "Kolom formulir",
      fieldKind: {
        password: "kata sandi",
        otp: "kode sekali pakai",
        pin: "nomor PIN",
        "recovery-code": "kode pemulihan",
        "secret-phrase": "frasa pemulihan",
        email: "alamat email",
        text: "teks",
        other: "lainnya"
      },
      unlabeledField: "(kolom tanpa label)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace tidak dapat memastikan siapa penulisnya. Pengakuan sebagai petugas atau pihak resmi bukan bukti.",
        "destination-not-scored": "Tujuan formulir hanya ditampilkan sebagai informasi; VeilTrace tidak menilai situs.",
        "trust-boundary-heuristic": "Apakah konten ini berasal dari situs atau dari pihak lain diperkirakan dari struktur halaman."
      }
    },
    pay: {
      findingTitle: { manipulative_instruction: "Permintaan pembayaran manipulatif", suspicious_correlation: "Permintaan pembayaran mencurigakan", observed_instruction: "Permintaan pembayaran" },
      ruleChip: (id) => `Aturan ${id}`,
      rule: {
        PR1: "Meminta Anda membayar lebih dulu untuk menerima sesuatu (refund, hadiah, dana yang dicairkan, atau akun yang dibuka). Refund dan hadiah asli tidak pernah meminta pembayaran di muka.",
        PR2: "Meminta Anda membayar di luar checkout biasa (rekening pribadi, di luar platform, kartu hadiah, atau kripto), disertai tekanan. Pembayaran seperti ini sulit ditarik kembali.",
        PR3: "Meminta pembayaran disertai ancaman (penutupan akun, penangkapan, atau tuntutan hukum) dan desakan atau klaim otoritas.",
        PR4: "Meminta pembayaran tanpa tanda manipulasi di sekitarnya."
      },
      promise: { refund: "refund", prize: "hadiah", "account-unlock": "akun yang dibuka kembali", release: "uang atau barang yang dilepas", recruitment: "kelulusan seleksi yang dijamin", job: "pekerjaan", "investment-return": "keuntungan investasi yang tetap atau dijamin", loan: 'pinjaman yang "disetujui" atau "pasti cair"' },
      destination: { "personal-account": "rekening pribadi", "off-platform": "di luar platform", "gift-card": "kartu hadiah", crypto: "aset kripto" },
      pressure: { threat: "ancaman", urgency: "tenggat atau desakan", "claimed-authority": "mengaku sebagai petugas atau otoritas", "claimed-family": "mengaku anggota keluarga dengan nomor baru" },
      promisesLabel: "Dijanjikan sebagai imbalan",
      destinationsLabel: "Pembayaran ditujukan ke",
      indicators: "Indikator",
      actionRisk: {
        high: "Risiko tindakan: tinggi. Uang yang dikirim dengan cara ini biasanya hilang.",
        medium: "Risiko tindakan: sedang. Membayar pihak yang salah dapat merugikan Anda."
      },
      signal: {
        "PY.PAY": "Permintaan pembayaran",
        "PA.AMOUNT": "Nominal",
        "PF.FEE": "Biaya",
        "PF.RELEASE_FEE": "Biaya pencairan atau buka blokir",
        "PD.PERSONAL": "Rekening pribadi",
        "PD.OFF_PLATFORM": "Di luar platform",
        "PD.GIFT_CARD": "Kartu hadiah",
        "PD.CRYPTO": "Aset kripto",
        "PR.REFUND": "Refund atau dana tertahan",
        "PR.PRIZE": "Hadiah",
        "PR.UNLOCK": "Pembukaan akun",
        "PR.RECRUIT": "Jaminan lulus seleksi",
        "PR.JOB": "Tawaran kerja",
        "PC.CONDITION": "Pembayaran sebagai syarat",
        "PP.THREAT": "Ancaman",
        "PP.FAMILY": "Mengaku keluarga",
        "PP.URGENCY": "Desakan",
        "PP.AUTHORITY": "Mengaku petugas atau otoritas",
        "C.NEGATION": "Negasi",
        "C.REPORTED": "Kalimat dilaporkan",
        "C.EDUCATIONAL": "Konteks edukasi"
      },
      amountHidden: "(nominal di halaman; nilainya tidak ditampilkan)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace tidak dapat memastikan siapa penulisnya. Pengakuan sebagai petugas, bank, atau polisi bukan bukti.",
        "trust-boundary-heuristic": "Apakah konten ini berasal dari situs atau dari pihak lain diperkirakan dari struktur halaman.",
        "amount-not-reported": "Nominal dicocokkan untuk memahami permintaan, tetapi nilainya tidak pernah disalin ke laporan."
      }
    },
    sup: {
      findingTitle: { manipulative_instruction: "Arahan dukungan yang manipulatif", suspicious_correlation: "Arahan dukungan yang mencurigakan", observed_instruction: "Arahan dukungan" },
      ruleChip: (id) => `Aturan ${id}`,
      rule: {
        SR1: "Halaman web mengklaim perangkat Anda terinfeksi atau terkunci lalu menyuruh Anda menelepon, menginstal, atau memberi akses. Browser dan sistem operasi tidak menampilkan alarm seperti itu di dalam halaman web.",
        SR2: "Pihak yang mengaku petugas, bank, atau admin meminta Anda menginstal perangkat lunak atau memberi akses jarak jauh, disertai tekanan atau dari konten yang mungkin tidak dikendalikan situs.",
        SR3: "Pihak yang mengaku petugas, bank, atau admin mengarahkan Anda ke kontak luar disertai ancaman terhadap akun atau data Anda.",
        SR4: "Komentar atau konten kiriman pengguna mengaku sebagai dukungan resmi dan mengarahkan Anda ke kontak luar.",
        SR5: "Mengarahkan Anda menghubungi petugas, menginstal perangkat lunak, atau memberi akses jarak jauh, tanpa tanda peniruan atau tekanan di sekitarnya.",
        SR6: "Pesan yang tampil sebagai pemberitahuan dari bank, e-wallet, marketplace, atau layanan pelanggannya membunyikan alarm, ancaman, atau hadiah, lalu meminta Anda membalas, memilih opsi, membuka tautan, atau mengisi formulir. Bank dan platform tidak menyelesaikan urusan seperti ini lewat balasan atau tautan di pesan.",
        SR7: "Mengucapkan selamat atas hadiah uang yang tidak pernah Anda ikuti, lalu meminta Anda menjawab kuis, sering atas nama ulang tahun perusahaan. Kuis seperti ini menggiring orang untuk menyebarkan tautan atau menyerahkan data atau uang.",
        SR8: "Menawarkan akses ke pesan, akun, atau HP orang lain lalu mengarahkan Anda ke kontak. Jasa seperti ini ilegal, dan pembelinya sering ditipu atau diperas.",
        SR9: "Seseorang yang mengaku pembeli, penyewa, atau pemilik mengarahkan Anda ke kerabat atau orang lain lewat nomor pribadi untuk urusan harga atau pembayaran. Modus pembeli palsu dan pengalihan pembayaran dimulai seperti ini.",
        SR10: "Pesan menawarkan file aplikasi Android (.apk) yang disebut sebagai undangan, foto paket, resi, surat tilang, atau tagihan, atau meminta Anda menginstalnya atau mematikan perlindungan HP. Membuka file seperti ini memasang aplikasi yang bisa membaca SMS dan mengambil alih aplikasi bank."
      },
      action: { contact: "menghubungi seseorang", respond: "membalas, memilih opsi, membuka tautan, atau mengisi formulir", survey: "menjawab kuis atau kuesioner", "remote-access": "memberi akses jarak jauh", install: "menginstal perangkat lunak", "disable-protection": "mematikan perlindungan perangkat atau mengizinkan aplikasi tak dikenal" },
      channel: { phone: "nomor telepon", mobile: "nomor ponsel", messenger: "aplikasi pesan", link: "tautan", "apk-file": "file aplikasi (.apk)" },
      claim: { support: "petugas atau layanan pelanggan", bank: "pihak bank", administrator: "admin", "security-team": "tim keamanan", official: "pejabat, aparat, atau penyidik", organization: "perusahaan atau instansi" },
      indicator: {
        "page-rendered-system-alert": "alarm virus atau kunci yang dibuat halaman web",
        "remote-access-request": "meminta akses jarak jauh",
        "software-install-request": "meminta Anda menginstal perangkat lunak",
        "personal-channel-contact": "klaim resmi dengan nomor ponsel atau aplikasi pesan",
        "claim-in-user-content": "klaim resmi di dalam konten kiriman pengguna",
        "alert-in-overlay": "alarm di overlay yang menutupi halaman",
        "protection-disable-request": "meminta mematikan perlindungan, mengizinkan aplikasi tak dikenal, atau memberi akses aksesibilitas",
        "apk-file-in-message": "file aplikasi (.apk) dikirim lewat pesan"
      },
      pressure: { "system-alert": "alarm perangkat", "account-alarm": "alarm akun (login, transaksi, atau tarif)", threat: "ancaman terhadap akun atau data", urgency: "tenggat atau desakan", reward: "hadiah atau poin", "pre-won": "ucapan selamat atas hadiah yang tidak Anda ikuti", "illicit-access": "tawaran akses ke akun atau HP orang lain", "third-party-redirect": "mengarahkan ke kerabat atau perantara lewat nomor pribadi", "document-pretext": "disebut sebagai undangan, foto paket, resi, surat tilang, atau tagihan" },
      asksLabel: "Meminta Anda",
      claimsLabel: "Mengaku sebagai (belum terverifikasi)",
      indicatorsLabel: "Indikator teramati",
      pressureLabel: "Tekanan",
      actionRisk: {
        high: "Risiko tindakan: tinggi. Menginstal perangkat lunak atau memberi akses jarak jauh dapat menyerahkan kendali perangkat kepada orang asing.",
        medium: "Risiko tindakan: sedang. Menghubungi layanan palsu dapat berujung pada permintaan uang, kode, atau akses."
      },
      signal: {
        "SC.CONTACT": "Arahan menghubungi",
        "SC.RESPOND": "Permintaan balasan, tautan, atau formulir",
        "SC.SURVEY": "Kuis atau kuesioner",
        "SA.REMOTE": "Permintaan akses jarak jauh",
        "SA.INSTALL": "Permintaan instalasi",
        "SX.PHONE": "Nomor telepon",
        "SX.MOBILE": "Nomor ponsel",
        "SX.MESSENGER": "Aplikasi pesan",
        "SX.LINK": "Tautan",
        "SI.SUPPORT": "Mengaku petugas",
        "SI.BANK": "Mengaku pihak bank",
        "SI.ADMIN": "Mengaku admin",
        "SI.SECURITY": "Mengaku tim keamanan",
        "SI.OFFICIAL": "Mengaku pejabat atau berpangkat",
        "SW.ALERT": "Alarm perangkat",
        "ST.THREAT": "Ancaman",
        "SU.URGENCY": "Desakan",
        "SW.ACCOUNT": "Alarm akun",
        "SP.REWARD": "Hadiah",
        "SP.WON": "Hadiah tanpa ikut",
        "SO.ILLICIT": "Tawaran akses ilegal",
        "SO.PROXY": "Dialihkan ke kerabat atau perantara",
        "SI.ORG": "Mengaku perusahaan atau instansi",
        "SH.UNASSERTED": "Pengandaian atau kutipan",
        "C.NEGATION": "Negasi",
        "C.REPORTED": "Kalimat dilaporkan",
        "C.EDUCATIONAL": "Konteks edukasi"
      },
      contactHidden: "(nomor kontak di halaman; tidak ditampilkan)",
      limitation: {
        "claimed-identity-unverifiable": "VeilTrace tidak dapat memastikan siapa penulisnya. Pengakuan sebagai petugas, bank, atau admin bukan bukti, dan VeilTrace tidak menyatakan organisasinya palsu.",
        "trust-boundary-heuristic": "Apakah konten ini berasal dari situs atau dari pihak lain diperkirakan dari struktur halaman.",
        "contact-details-not-reported": "Nomor telepon dicocokkan untuk memahami arahan, tetapi tidak pernah disalin ke laporan."
      }
    },
    pwa: {
      title: "Cek pesan",
      intro: "Tempel pesan yang mencurigakan, atau periksa screenshot-nya, untuk melihat apakah pesan itu mencoba memanipulasi Anda. Screenshot dibaca di perangkat ini.",
      sourceLabel: "Dari mana pesannya?",
      source: { chat: "Chat (WhatsApp, Telegram\u2026)", sms: "SMS", email: "Email", web: "Teks dari situs" },
      placeholder: "Tempel pesan di sini\u2026",
      check: "Periksa pesan",
      clear: "Hapus",
      paste: "Tempel dari clipboard",
      shareHint: "Di Android, pasang aplikasi ini, lalu bagikan pesan atau screenshot ke VeilTrace.",
      privacy: "Diperiksa hanya di perangkat ini. Pesan tidak dikirim, disimpan, atau dibagikan.",
      empty: "Tempel atau bagikan pesan terlebih dahulu.",
      tooLong: "Hanya 20.000 karakter pertama yang diperiksa.",
      assessment: "PENILAIAN ANCAMAN PESAN",
      headlineDetail: {
        manipulative_instruction: "Pesan ini mencoba membuat Anda melakukan sesuatu yang merugikan. Jangan ikuti instruksi yang tercantum di bawah.",
        suspicious_correlation: "Pesan ini menggabungkan permintaan dengan tanda yang sering muncul dalam penipuan. Periksa temuan di bawah sebelum bertindak.",
        observed_instruction: "Instruksi atau permintaan biasa ditemukan dan dicantumkan sebagai teramati. Ini bukan jaminan tentang pesan ini.",
        none: "VeilTrace tidak menemukan apa pun untuk dilaporkan di teks ini. Ini bukan jaminan tentang pesan atau pengirimnya."
      },
      linkOnly: "Yang ditempel hanya tautan. VeilTrace memeriksa isi pesan dan tidak menilai alamat situs. Tempel seluruh pesannya, termasuk teks di sekitar tautan. Jangan membuka tautan hanya untuk mengeceknya.",
      yourMessage: "Pesan Anda",
      offlineReady: "Siap dipakai tanpa internet.",
      image: "Periksa screenshot",
      ocrProgress: (p) => `Membaca teks di gambar, di perangkat ini\u2026 ${p}%`,
      ocrDone: "Teks sudah dibaca dari gambar. Cocokkan dengan gambarnya dan perbaiki bila perlu, lalu periksa lagi.",
      ocrEmpty: "Tidak ada teks yang terbaca dari gambar ini. Coba screenshot yang lebih jelas, atau tempel teksnya.",
      ocrFailed: "Gambar tidak bisa dibaca di perangkat ini. Tempel teksnya saja."
    },
    imageText: {
      title: "Teks di dalam gambar \xB7 di perangkat ini",
      intro: "Sebagian umpan ditulis di dalam gambar (poster, banner, foto surat). VeilTrace dapat membaca bagian halaman yang terlihat dari screenshot, di perangkat ini, lalu memeriksa teks yang belum ada sebagai teks halaman. Tidak ada yang dikirim.",
      run: "Baca teks di gambar",
      reading: (p) => `Membaca layar yang terlihat, di perangkat ini\u2026 ${p}%`,
      analyzing: "Memeriksa teks yang ditemukan di gambar\u2026",
      done: (n) => `${n} baris teks hanya ditemukan di dalam gambar pada layar yang terlihat.`,
      nothing: "Tidak ada teks di dalam gambar pada layar yang terlihat selain yang sudah ada sebagai teks halaman. Gulir lalu baca lagi untuk memeriksa bagian lain.",
      noText: "Tidak ada teks yang terbaca dari layar yang terlihat.",
      failed: "Layar tidak bisa dibaca di sini. Beberapa halaman dan browser tidak mengizinkan screenshot.",
      notShowable: "Di dalam gambar: tidak bisa di-highlight di halaman."
    },
    ai: {
      title: "Pendapat kedua AI \xB7 opsional, di perangkat ini",
      intro: "Model AI bawaan Chrome dapat membaca teks halaman ini dan memberi pendapat kedua. Berjalan di perangkat ini dan tidak ada yang dikirim. Hasil VeilTrace di atas tidak berubah.",
      prepare: "Tampilkan teks yang akan dibaca AI",
      previewSummary: (n, cut) => `${n} baris teks halaman; nomor, tautan, dan alamat email disamarkan${cut ? "; dipotong agar muat" : ""}`,
      run: "Tanya AI di perangkat",
      running: "AI sedang membaca teks\u2026",
      downloading: (p) => `Chrome sedang mengunduh model AI\u2026 ${p}%`,
      unsupported: "Tidak tersedia di browser ini. AI di perangkat butuh Chrome di Windows, macOS, Linux, atau Chromebook Plus dengan model bawaannya.",
      unavailable: "Model AI bawaan Chrome tidak tersedia di perangkat ini (perangkat keras, ruang penyimpanan, atau pengaturan).",
      failed: "AI tidak memberi jawaban yang dapat dipakai. Coba lagi.",
      noText: "Tidak ada teks halaman untuk dibaca.",
      resultTitle: "Pendapat AI \xB7 bisa keliru",
      assessment: { manipulative: "AI melihat tanda manipulasi.", suspicious: "AI melihat beberapa tanda mencurigakan.", "no-clear-signs": "AI tidak melihat tanda manipulasi yang jelas. Ini bukan jaminan." },
      tactic: {
        impersonation: "mengaku bank, perusahaan, layanan pelanggan, atau pejabat",
        "threat-or-urgency": "ancaman, alarm, atau tenggat",
        "too-good-to-be-true": "hadiah, refund, atau pekerjaan yang terlalu bagus",
        "payment-request": "meminta pembayaran",
        "credential-request": "meminta password, kode, atau PIN",
        "link-or-reply-lure": "tautan, balasan, kuis, atau formulir sebagai umpan",
        "run-command": "menyuruh menjalankan perintah",
        "remote-access-or-install": "menyuruh memasang aplikasi atau memberi akses jarak jauh",
        "illegal-service": "menawarkan jasa ilegal",
        "personal-contact-channel": "nomor ponsel atau aplikasi pesan pribadi"
      },
      confidence: { low: "Keyakinan AI: rendah", medium: "Keyakinan AI: sedang", high: "Keyakinan AI: tinggi" },
      tacticsLabel: "Taktik yang disebut AI",
      citedLines: "Baris yang ditunjuk AI",
      disagreeAlert: "AI dan VeilTrace berbeda pendapat. VeilTrace tidak menemukan pola manipulasi yang terdokumentasi di halaman ini. Baca sendiri baris yang ditunjuk AI: AI bisa keliru.",
      disagreeQuiet: "AI dan VeilTrace berbeda pendapat. AI tidak melihat apa yang ditemukan VeilTrace; temuan VeilTrace di atas menunjukkan bukti yang menjadi dasarnya.",
      caveat: "Pendapat dari model bahasa: bisa keliru atau terkecoh oleh halaman itu sendiri, dan bahasa Indonesia belum termasuk bahasa yang didukungnya. Tidak mengubah hasil VeilTrace."
    },
    auto: {
      actionTitle: "VeilTrace: pindai halaman ini",
      badgeTitle: "VeilTrace: konten manipulatif ditemukan di halaman ini. Klik untuk detail.",
      title: "Mode pemindaian",
      modeLabel: { manual: "MANUAL", automatic: "OTOMATIS" },
      manualText: "Manual: VeilTrace membaca halaman hanya saat Anda menekan Pindai halaman.",
      automaticText: 'Otomatis: VeilTrace memeriksa halaman saat dimuat dan berubah, dan memberi tanda "!" pada ikon toolbar jika menemukan konten manipulatif.',
      consent: "Browser akan meminta izin agar VeilTrace dapat membaca semua situs. Halaman tetap dianalisis hanya di perangkat ini: tidak ada yang dikirim, disimpan, atau dibagikan, dan isian formulir tidak pernah dibaca. Berlaku untuk halaman yang dibuka atau dimuat ulang setelahnya, dan dapat dimatikan di sini atau di pengaturan Chrome kapan saja.",
      managedText: "Pemindaian otomatis diaktifkan oleh organisasi Anda. Halaman tetap dianalisis hanya di perangkat ini; tidak ada yang dilaporkan ke organisasi Anda atau pihak lain.",
      enable: "Aktifkan pemindaian otomatis",
      disable: "Matikan pemindaian otomatis",
      denied: "Izin tidak diberikan. VeilTrace tetap dalam mode manual.",
      failed: "Mode pemindaian tidak dapat diubah. Coba lagi."
    },
    dash: {
      stateLabel: { standby: "SIAGA", scanning: "MEMINDAI", complete: "PEMINDAIAN LENGKAP", partial: "PEMINDAIAN SEBAGIAN", error: "PEMINDAIAN GAGAL" },
      assessment: "PENILAIAN ANCAMAN HALAMAN",
      headline: {
        manipulative_instruction: {
          tone: "danger",
          title: "Konten manipulatif terdeteksi",
          detail: "Halaman ini mencoba membuat Anda melakukan sesuatu yang merugikan. Jangan ikuti instruksi yang tercantum di bawah."
        },
        suspicious_correlation: {
          tone: "warning",
          title: "Konten mencurigakan terdeteksi",
          detail: "Halaman ini menggabungkan permintaan dengan tanda yang sering muncul dalam penipuan. Periksa temuan di bawah sebelum bertindak."
        },
        observed_instruction: {
          tone: "neutral",
          title: "Tidak ada tanda manipulasi di konten yang dianalisis",
          detail: "Instruksi atau permintaan biasa ditemukan dan dicantumkan sebagai teramati. Ini bukan jaminan tentang halaman."
        },
        none: {
          tone: "neutral",
          title: "Tidak ada yang perlu dilaporkan di konten yang dianalisis",
          detail: "VeilTrace tidak menemukan temuan di bagian yang dapat diperiksa. Ini bukan jaminan tentang halaman."
        }
      },
      statHighest: "Klasifikasi tertinggi",
      statActionable: "Perlu tindakan",
      statCategories: "Kategori terdampak",
      statCoverage: "Cakupan pemindaian",
      coverageValue: { complete: "Lengkap", partial: "Sebagian" },
      noCategories: "Tidak ada",
      verdictLabel: { manipulative_instruction: "Manipulatif", suspicious_correlation: "Mencurigakan", observed_instruction: "Hanya teramati", none: "Tidak ada temuan" },
      overviewTitle: "Kategori deteksi",
      categoryName: {
        command: "Manipulasi Eksekusi Perintah",
        credential: "Manipulasi Pengungkapan Kredensial",
        payment: "Manipulasi Pembayaran",
        support: "Peniruan Dukungan & Otoritas"
      },
      categoryCode: { command: "CMD", credential: "CRED", payment: "PAY", support: "SUP" },
      tileCount: (total, actionable) => total === 0 ? "0 temuan" : `${actionable} perlu tindakan \xB7 ${total} total`,
      experimental: "Eksperimental",
      experimentalNote: "Pemeriksaan kredensial, pembayaran, dan dukungan bersifat eksperimental dan belum lulus evaluasi independen. Hanya teks halaman dan struktur formulir yang dibaca, tidak pernah isian Anda, dan nominal maupun nomor telepon tidak pernah disalin.",
      findingsTitle: (n) => `Temuan (${n})`,
      observedTitle: (n) => `Teramati tanpa tanda manipulasi (${n})`,
      groupTitle: (n) => `${n} temuan terkait pada elemen halaman yang sama`,
      groupNote: "Temuan setiap detektor ditampilkan dengan buktinya sendiri.",
      alsoCitedBy: (c) => `Juga dirujuk oleh: ${c}`,
      evidenceTitle: "Bukti teramati",
      evidenceId: (id) => `ID bukti ${id}`,
      findingId: (id) => `ID temuan ${id}`,
      actionRiskChip: { high: "Risiko tindakan: tinggi", medium: "Risiko tindakan: sedang" },
      adviceTitle: "Yang perlu dilakukan",
      advice: {
        command: "Jangan tekan Win+R, membuka terminal, menempel, atau menjalankan apa pun yang diminta halaman ini. CAPTCHA asli tidak pernah meminta Anda menjalankan perintah.",
        credential: "Jangan kirim kata sandi, kode sekali pakai, atau frasa pemulihan kepada siapa pun. Masuk hanya di situs yang Anda buka sendiri.",
        payment: "Jangan membayar untuk menerima refund, hadiah, atau pembukaan akun, dan jangan membayar ke rekening pribadi, kartu hadiah, atau kripto atas permintaan. Hubungi organisasinya lewat saluran yang sudah Anda kenal.",
        support: "Jangan menelepon nomor atau menghubungi akun yang muncul di peringatan atau komentar. Cari sendiri kontak resmi organisasinya.",
        remoteAccess: "Jangan pernah menginstal aplikasi akses jarak jauh (AnyDesk, TeamViewer) atau perangkat lunak lain karena diminta orang yang mengaku petugas."
      },
      adviceNone: "Tidak adanya temuan tidak membuat halaman dapat dipercaya. VeilTrace hanya memeriksa yang terlihat di halaman ini, pada saat pemindaian."
    },
    errors: {
      noPageTitle: "Tidak ada halaman untuk dipindai",
      noPageDetail: "Buka sebuah halaman web, lalu klik tombol VeilTrace lagi.",
      restrictedTitle: "Halaman ini tidak dapat dipindai",
      restrictedDetail: "Halaman yang dilindungi browser (seperti halaman internal browser, toko ekstensi, dan ekstensi lain) tidak mengizinkan ekstensi membacanya.",
      accessTitle: "VeilTrace tidak dapat mengakses halaman ini",
      accessDetail: "Halaman mungkin memblokir ekstensi atau sudah berubah. Muat ulang halaman lalu coba lagi.",
      fileDetail: 'Untuk memindai file lokal, aktifkan "Izinkan akses ke URL file" untuk VeilTrace di halaman ekstensi browser Anda.',
      badReportTitle: "Pemindaian gagal",
      badReportDetail: "Pemindaian mengembalikan data yang tidak terduga dan data itu dibuang."
    }
  }, MESSAGES = { en: EN, id: ID };
  function detectLang(uiLanguage) {
    return /^(id|in)(?:[-_]|$)/i.test(uiLanguage ?? "") ? "id" : "en";
  }

  // src/extension/background/worker.ts
  onAutoSummary((tabId, s) => {
    let m = MESSAGES[detectLang(chrome.i18n.getUILanguage())], badge = badgeFor(s);
    chrome.action.setBadgeText({ tabId, text: badge.text }).catch(() => {
    }), chrome.action.setBadgeBackgroundColor({ tabId, color: badge.color }).catch(() => {
    }), chrome.action.setTitle({ tabId, title: badge.text ? m.auto.badgeTitle : m.auto.actionTitle }).catch(() => {
    });
  });
  chrome.runtime.onInstalled.addListener(() => {
    ensureManagedAuto().catch(() => {
    });
  });
  chrome.runtime.onStartup.addListener(() => {
    ensureManagedAuto().catch(() => {
    });
  });
  chrome.permissions.onRemoved.addListener(() => {
    chrome.scripting.unregisterContentScripts({ ids: [AUTO_SCRIPT_ID] }).catch(() => {
    });
  });
})();
