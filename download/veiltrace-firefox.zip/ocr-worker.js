"use strict";
(() => {
  // src/extension/ocr/worker.ts
  var scope = self, ready = null, progress = null;
  async function gunzip(b64) {
    let bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0)), stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  async function init() {
    scope.importScripts("ocr-core.js", "ocr-lang-ind.js", "ocr-lang-eng.js");
    let mod = await TesseractCore({ TesseractProgress: (pct) => progress?.(Math.max(0, (pct - 30) / 70)) });
    for (let lang of ["ind", "eng"]) mod.FS.writeFile(`${lang}.traineddata`, await gunzip(__vtOcrLang[lang]));
    let api = new mod.TessBaseAPI();
    if (api.Init(null, "ind+eng", 1) !== 0) throw new Error("init");
    return { mod, api };
  }
  scope.onmessage = async (e) => {
    let { id, image } = e.data;
    try {
      ready ??= init();
      let { mod, api } = await ready;
      progress = (p) => scope.postMessage({ id, progress: p }), mod.FS.writeFile("/input", new Uint8Array(image));
      let texts = [];
      for (let method of ["0", "1"]) {
        if (api.SetVariable("thresholding_method", method), api.SetImageFile(1, 0) === 1) throw new Error("image");
        api.Recognize(null), texts.push(api.GetUTF8Text()), api.Clear();
      }
      mod.FS.unlink("/input"), scope.postMessage({ id, texts });
    } catch {
      ready = null, scope.postMessage({ id, error: !0 });
    } finally {
      progress = null;
    }
  };
})();
